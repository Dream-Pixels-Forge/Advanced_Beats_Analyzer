# Advanced Beat Analyzer for Blender

## Overview
Advanced Beat Analyzer is a powerful Blender addon designed specifically for motion designers and video editors. It provides professional-grade audio analysis and visualization tools, making it easier to create audio-reactive animations and synchronize visual elements with music.

## Key Features
- 🎵 Two dedicated audio value nodes:
  - AVS (Audio Value Shader) for material animations
  - AVG (Audio Value Geometry) for geometry nodes
- 🎨 Audio-reactive animations for both Shader and Geometry Nodes
- 🎬 Real-time audio visualization
- 🎭 Independent control over shader and geometry animations
- ⚡ Optimized audio baking system
- 🔧 Customizable smoothing and limits

## Perfect for
- Motion Designers
- Video Editors
- 3D Animators
- Music Video Creators
- Live Visual Artists
- Anyone working with audio-driven animations

## Installation
1. Download the `advanced_beat_analyzer.zip` file
2. Open Blender and go to Edit > Preferences > Add-ons
3. Click "Install" and select the downloaded file
4. Enable the addon by checking the box

## Quick Start Guide
1. Open the Beat Analyzer panel in the 3D View sidebar
2. Select your audio file
3. Choose your target:
   - Click "Bake to AVS" for material animations
   - Click "Bake to AVG" for geometry animations
4. Adjust smoothing settings if needed
5. Use the generated animations in your nodes

## Features in Detail

### Audio Value Nodes
- AVS (Audio Value Shader):
  - Automatically creates material node setup
  - Optimized for shader-based animations
  - Built-in noise texture and color ramp
  - Emission-based visualization

- AVG (Audio Value Geometry):
  - Dedicated geometry nodes setup
  - 4D noise texture integration
  - Automatic modifier setup
  - Geometry-based visualization

### Node Setups
#### Shader Setup (AVS)
- Value node for audio input
- Noise texture for variation
- Color ramp for control
- Principled BSDF integration
- Emission-based output

#### Geometry Setup (AVG)
- Value node for audio input
- 4D noise texture
- Group input/output nodes
- Automatic geometry pass-through
- Ready for custom geometry node networks

### Animation Controls
- Independent baking for AVS and AVG
- Customizable smoothing
- Automatic limit controls
- Real-time preview
- Non-destructive workflow

## Workflow Integration
### For Motion Designers
- Create audio-reactive materials using AVS
- Drive parameters with beat intensity
- Real-time visualization feedback
- Non-destructive material animations

### For Technical Artists
- Use AVG for geometry deformation
- Create procedural animations
- Combine with existing geometry nodes
- Complex audio-driven effects

## Performance Tips
- Bake one node at a time
- Adjust smoothing for better performance
- Use appropriate value ranges
- Optimize node networks

## Technical Requirements
- Blender 3.0 or newer
- Supported audio formats: WAV, MP3, etc.
- Basic understanding of node systems

## Known Limitations
- Audio preview requires baking
- Large files may require more processing time
- Real-time preview may affect performance

## Troubleshooting
- If baking fails, check audio file format
- If animation is too extreme, adjust limits
- If motion is jerky, increase smoothing
- If nodes are missing, rebake the animation

## Updates and Support
- Check for updates regularly
- Report issues on the repository
- Join our community for tips and tricks

## Credits
Created by Dimona Patrick
Version 2.1.2

## License
This addon is released under the GPL-3.0 License.

---

Advanced Beat Analyzer streamlines the process of creating audio-reactive animations in Blender. With dedicated nodes for both shader and geometry workflows, it provides a powerful yet intuitive system for creating stunning audio-visual content.
